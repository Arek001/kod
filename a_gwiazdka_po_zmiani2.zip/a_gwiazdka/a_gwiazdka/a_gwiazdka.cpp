﻿#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
class Punkt {
public:
    int x, y;
    float f, g, h;
    int rodzic_x, rodzic_y;

    Punkt(int x, int y) {
        this->x = x;
        this->y = y;
        this->f = 0;
        this->g = 0;
        this->h = 0;
        this->rodzic_x = -1;
        this->rodzic_y = -1;
    }
};

bool czy_dostepne(int x, int y, vector<vector<int>> mapa) {
    if (x >= 0 && x < 20 && y >= 0 && y < 20) {
        if (mapa[y][x] != 5) {
            return true; //  oznacza dostępne pole
        }
        else {
            return false; // 5 oznacza niedostępne pole
        }
    }
    else {
        return false; // poza zakresem mapy
    }
}

void dodaj_do_otwartej( Punkt sasiad, float f_nowe, float g_nowe, float h_nowe, int rodzic_x, int rodzic_y, vector<Punkt>& lista_otwarta) {
    bool dodaj_do_otwartej = false;

    for (int i = 0; i < lista_otwarta.size(); i++) {
        Punkt punkt = lista_otwarta[i];
        if (punkt.x == sasiad.x && punkt.y == sasiad.y) {
            dodaj_do_otwartej = true;
            if (f_nowe < punkt.f) {
                punkt.f = f_nowe;
                punkt.g = g_nowe;
                punkt.h = h_nowe;
                punkt.rodzic_x = rodzic_x;
                punkt.rodzic_y = rodzic_y;
                break;
            }
        }
    }

    if (!dodaj_do_otwartej) {
        Punkt nowy_sasiad(sasiad.x, sasiad.y);
        nowy_sasiad.g = g_nowe;
        nowy_sasiad.h = h_nowe;
        nowy_sasiad.f = f_nowe;
        nowy_sasiad.rodzic_x = rodzic_x;
        nowy_sasiad.rodzic_y = rodzic_y;
        lista_otwarta.push_back(nowy_sasiad);
    }
}

void dodaj_do_zamknietej(Punkt aktualny, vector<Punkt>& lista_zamknieta) {
    bool dodaj_do_zamknietej = true;

    for (int i = 0; i < lista_zamknieta.size(); i++) {
        Punkt punkt = lista_zamknieta[i];
        if (punkt.x == aktualny.x && punkt.y == aktualny.y) {
            dodaj_do_zamknietej = false;
            break;
        }
    }

    if (dodaj_do_zamknietej) {
        lista_zamknieta.push_back(aktualny);
    }
}

vector<Punkt> znajdz_sciezke(vector<vector<int>> mapa) {
    vector<Punkt> lista_otwarta;
    vector<Punkt> lista_zamknieta;

    Punkt start(19, 0); // Startujemy z punktu (19, 0)
    lista_otwarta.push_back(start);

    //int maksymalna_liczba_iteracji = 10000;
    //int liczba_iteracji = 0;

    for (int i = 0; lista_otwarta.size() > 0 ; i++) {
        stable_sort(lista_otwarta.begin(), lista_otwarta.end(), [](Punkt a, Punkt b) {
            return a.f > b.f;
            });

        Punkt aktualny = lista_otwarta.back();
        lista_otwarta.pop_back();
        dodaj_do_zamknietej(aktualny, lista_zamknieta);

        if (aktualny.x == 0 && aktualny.y == 19) {

            vector<Punkt> sciezka;
            
       
            for (int i = 0; i < lista_otwarta.size(); i++) {
                sciezka.push_back(aktualny);
                for (Punkt punkt : lista_zamknieta) {
                    if (punkt.x == aktualny.rodzic_x && punkt.y == aktualny.rodzic_y) {
                        aktualny = punkt;
                     
                       

                    }

                }
             
               

            }

            
            return sciezka;
        
        }
      

        if (lista_otwarta.empty() && !(aktualny.x == 0 && aktualny.y == 19)) {
                cout << "nie znaleziono sciezki";
        }
        
        // Sprawdź sąsiadów
        int sasiedzi_x[4] = { -1, 1, 0, 0 }; // 1 w górę, 1 w dół
        int sasiedzi_y[4] = { 0, 0, -1, 1 }; // 1 w lewo, 1 w prawo

        
        for (int i = 0; i < 4; i++) {
            int nowy_y = aktualny.y + sasiedzi_y[i];
            int nowy_x = aktualny.x + sasiedzi_x[i];
        

            if (!czy_dostepne(nowy_x, nowy_y, mapa)) {
                continue;
            }

            int g_nowe = aktualny.g + 1;
            float c = (nowy_x - 0);
            float d = (nowy_y - 19);
            float h_nowe = sqrt((c * c) + (d * d));
            float f_nowe = g_nowe + h_nowe;

            dodaj_do_otwartej(Punkt(nowy_x, nowy_y), f_nowe, g_nowe, h_nowe, aktualny.x, aktualny.y, lista_otwarta);
           
        }



        //liczba_iteracji++;
    }

    //throw runtime_error("Nie znaleziono sciezki");
}

void wypisz_mape(vector<vector<int>> mapa, vector<Punkt> sciezka) {
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 20; j++) {
            bool jest_na_sciezce = false;
            for (Punkt punkt : sciezka) {
                if (punkt.x == j && punkt.y == i) {
                    jest_na_sciezce = true;
                    break;
                }
            }
            if (jest_na_sciezce) {
                cout << "3 ";
            }
            else {
                if (mapa[i][j] == 0) {
                    cout << '0';
                }
                else {
                    cout << '5';
                }
                cout << ' ';
            }
        }
        cout << endl;
    }
}

int main() {
    
    vector<vector<int>> mapa(20, vector<int>(20, 0)); /*dwuwymiarowy wektor o wymiarach 20x20, początkowo wypełnionym zerami*/

    ifstream plik("grid.txt");
    if (plik.is_open()) {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 20; j++) {
                plik >> mapa[i][j];
            }
        }
        plik.close();
    }
    
    else {
        cerr << "Nie mozna otworzyc pliku grid.txt." << endl;
        return 1;
    }
    

    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 20; j++) {
            if (mapa[i][j] == 0) {
                cout << '0';
            }

            else {
                cout << '5';
            }
            cout << " ";
            
        }
            
        cout << endl;
    }
    
    try {
        vector<Punkt> sciezka = znajdz_sciezke(mapa);

        cout << endl;
        cout << endl;
        cout << endl;

        wypisz_mape(mapa, sciezka);
    }
    catch (const exception& e) {
        cerr << e.what() << endl;
    }

    return 0;
}
